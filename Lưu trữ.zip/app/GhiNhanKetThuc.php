<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GhiNhanKetThuc extends Model
{
    protected $table='ghinhanketthuc';
    public $timestamps = false;
}
